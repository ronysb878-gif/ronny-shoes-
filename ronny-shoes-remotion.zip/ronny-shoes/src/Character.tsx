import React from 'react';
import {useCurrentFrame} from 'remotion';
import {OUT} from './theme';
import {Shoe, Kind} from './Art';

export type Emo = 'normal' | 'happy' | 'sad' | 'worried' | 'surprised' | 'hopeful' | 'determined';
export type Who = 'ronny' | 'baba' | 'salam' | 'extra';
export interface CP {
  who: Who; x: number; y: number; s?: number; flip?: boolean; emo?: Emo; talk?: boolean;
  lookX?: number; lookY?: number; armL?: number; armR?: number; holdL?: React.ReactNode; holdR?: React.ReactNode;
  noArms?: boolean; walk?: boolean; tremble?: number; seed?: number; shoeL?: Kind; shoeR?: Kind; socks?: boolean;
  hideLegs?: boolean; tears?: boolean; tilt?: number; shirt?: string; pants?: string; hair?: string;
}
// y = পায়ের তলার অবস্থান (ground), x = শরীরের মাঝ; s = স্কেল। হাতের কোণ: ০ = ঝুলানো, ধনাত্মক = বাইরের দিকে, ঋণাত্মক = শরীরের ভেতরের দিকে
const N = {stroke: OUT, strokeWidth: 3.5, vectorEffect: 'non-scaling-stroke', strokeLinejoin: 'round', strokeLinecap: 'round'} as const;
const LOOK = {
  ronny: {skin: '#E8B48A', shirt: '#FFFFFF', pants: '#1F3A6B', hair: '#1B1B1B', eye: 17},
  baba: {skin: '#D9A06F', shirt: '#9CC7EA', pants: '#7A7F87', hair: '#1B1B1B', eye: 13},
  salam: {skin: '#C98F5E', shirt: '#F4F1EA', pants: '#2F6FA8', hair: '#CFCFCF', eye: 13},
  extra: {skin: '#E3AE82', shirt: '#F2A65A', pants: '#3B4A5A', hair: '#2A1E18', eye: 15},
};
const BROW: Record<Emo, [number, number, number]> = {
  normal: [0, 0, 0], sad: [-16, 16, -2], worried: [-14, 14, -4], hopeful: [-10, 10, -8], happy: [0, 0, -8], surprised: [0, 0, -16], determined: [14, -14, 0],
};

const Eye = ({cx, r, blink, lx, ly}: {cx: number; r: number; blink: number; lx: number; ly: number}) => (
  <g transform={`translate(${cx},142) scale(1,${blink})`}>
    <ellipse rx={r} ry={r * 1.05} fill="#fff" {...N} />
    <circle cx={lx * r * 0.35} cy={ly * r * 0.3} r={r * 0.5} fill="#222" />
    <circle cx={lx * r * 0.35 + r * 0.15} cy={ly * r * 0.3 - r * 0.18} r={r * 0.16} fill="#fff" />
  </g>
);

const Mouth = ({m, emo}: {m: number; emo: Emo}) => {
  if (m === 1) return <ellipse cx={150} cy={190} rx={11} ry={6} fill="#7A1F1F" {...N} />;
  if (m === 2) return (<g><ellipse cx={150} cy={192} rx={14} ry={12} fill="#7A1F1F" {...N} /><ellipse cx={150} cy={199} rx={8} ry={5} fill="#E0707A" /></g>);
  const d = emo === 'happy' || emo === 'hopeful' ? 'M128,184 Q150,208 172,184'
    : emo === 'sad' || emo === 'worried' ? 'M132,197 Q150,182 168,197'
    : emo === 'determined' ? 'M136,192 L164,192' : 'M134,190 Q150,197 166,190';
  if (emo === 'surprised') return <ellipse cx={150} cy={192} rx={9} ry={12} fill="#7A1F1F" {...N} />;
  return <path d={d} fill="none" {...N} />;
};

const Leg = ({cx, sw, pants, kind, flip, socks}: {cx: number; sw: number; pants: string; kind: Kind; flip: boolean; socks: boolean}) => (
  <g transform={`rotate(${sw},${cx},385)`}>
    <rect x={cx - 18} y={380} width={36} height={148} rx={18} fill={pants} {...N} />
    {socks ? <ellipse cx={cx + (flip ? -4 : 4)} cy={540} rx={26} ry={12} fill="#F5F5F5" {...N} /> : <Shoe kind={kind} x={cx + (flip ? -6 : 6)} y={556} s={0.5} flip={flip} />}
  </g>
);

export const Character = (p: CP) => {
  const f = useCurrentFrame();
  const L = LOOK[p.who];
  const sk = L.skin, shirt = p.shirt ?? L.shirt, pants = p.pants ?? L.pants, hair = p.hair ?? L.hair;
  const s = p.s ?? 1.45, emo = p.emo ?? 'normal', seed = p.seed ?? 0;
  const bob = Math.sin((f + seed * 9) / 14) * 5 + (p.walk ? -Math.abs(Math.sin(f / 4)) * 10 : 0);
  const trem = p.tremble ? Math.sin(f * 2.6) * p.tremble : 0;
  const blink = (f + seed * 17) % 96 < 4 ? 0.1 : 1;
  const mouth = p.talk ? [1, 2, 1, 0, 2, 1][Math.floor((f + seed) / 3) % 6] : 0;
  const sw = p.walk ? Math.sin(f / 4) * 22 : 0;
  const lx = p.lookX ?? 0, ly = p.lookY ?? 0;
  const baba = p.who === 'baba', salam = p.who === 'salam', ronny = p.who === 'ronny';
  const bw = baba ? 134 : 124, bx = 150 - bw / 2;
  const [bl, br, bdy] = BROW[emo];
  const er = L.eye * (emo === 'surprised' ? 1.15 : 1);

  const Arm = ({side, ang, hold}: {side: -1 | 1; ang: number; hold?: React.ReactNode}) => (
    <g transform={`translate(${side < 0 ? 92 : 208},242) rotate(${side < 0 ? ang : -ang})`}>
      <rect x={-15} y={-8} width={30} height={125} rx={15} fill={baba ? shirt : sk} {...N} />
      {!baba && !salam && <rect x={-16} y={-9} width={32} height={48} rx={14} fill={shirt} {...N} />}
      <circle cy={122} r={17} fill={sk} {...N} />
      {salam && <ellipse cy={125} rx={9} ry={6} fill="#444" opacity={0.55} />}
      <g transform="translate(0,124)">{hold}</g>
    </g>
  );

  return (
    <g transform={`translate(${p.x + trem},${p.y + bob}) scale(${p.flip ? -s : s},${s}) translate(-150,-560)`}>
      <defs>
        <pattern id="chk" width={24} height={24} patternUnits="userSpaceOnUse">
          <rect width={24} height={24} fill="#2F6FA8" /><path d="M0,12H24M12,0V24" stroke="#F3F3F3" strokeWidth={3} /><path d="M0,0H24M0,0V24" stroke="#1B3F66" strokeWidth={2} />
        </pattern>
      </defs>
      {ronny && <rect x={76} y={232} width={148} height={150} rx={26} fill="#3E9B5A" {...N} />}
      {salam ? (
        <g>
          <rect x={74} y={486} width={152} height={20} rx={6} fill="#B07A45" {...N} />
          <rect x={84} y={506} width={18} height={56} rx={4} fill="#B07A45" {...N} /><rect x={198} y={506} width={18} height={56} rx={4} fill="#B07A45" {...N} />
          <ellipse cx={118} cy={552} rx={24} ry={11} fill={sk} {...N} /><ellipse cx={182} cy={552} rx={24} ry={11} fill={sk} {...N} />
          <path d="M92,360 L208,360 L232,492 L68,492Z" fill="url(#chk)" {...N} />
        </g>
      ) : !p.hideLegs ? (
        <g>
          <rect x={92} y={366} width={116} height={40} rx={10} fill={pants} {...N} />
          <Leg cx={122} sw={sw} pants={pants} kind={p.shoeL ?? 'old'} flip socks={!!p.socks} />
          <Leg cx={178} sw={-sw} pants={pants} kind={p.shoeR ?? 'old'} flip={false} socks={!!p.socks} />
        </g>
      ) : <rect x={92} y={366} width={116} height={40} rx={10} fill={pants} {...N} />}
      <rect x={135} y={196} width={30} height={34} fill={sk} {...N} />
      <rect x={bx} y={215} width={bw} height={165} rx={38} fill={shirt} {...N} />
      {ronny && (<g><rect x={106} y={222} width={16} height={132} fill="#3E9B5A" {...N} /><rect x={178} y={222} width={16} height={132} fill="#3E9B5A" {...N} /><path d="M132,216 L150,238 L168,216" fill="#fff" {...N} /></g>)}
      {baba && (<g><path d="M126,216 L150,248 L174,216Z" fill="#DCEBF7" {...N} />{[272, 312, 352].map((by) => <circle key={by} cx={150} cy={by} r={3.5} fill="#222" />)}</g>)}
      {salam && (<g>
        {[[112, 262], [190, 300], [140, 338]].map(([hx, hy], i) => <circle key={i} cx={hx} cy={hy} r={8} fill={sk} stroke={OUT} strokeWidth={2} vectorEffect="non-scaling-stroke" />)}
        <path d="M86,226 L132,222 L114,332 L82,332Z" fill="#D9534F" {...N} /><path d="M96,250 L124,246 M92,282 L118,278" stroke="#fff" strokeWidth={4} />
      </g>)}
      {p.who === 'extra' && <path d="M130,216 L150,236 L170,216" fill="#fff" {...N} />}
      {!p.noArms && <Arm side={-1} ang={p.armL ?? 4} hold={p.holdL} />}
      {!p.noArms && <Arm side={1} ang={p.armR ?? 4} hold={p.holdR} />}
      <g transform={`rotate(${p.tilt ?? 0},150,200)`}>
        <ellipse cx={88} cy={146} rx={12} ry={18} fill={sk} {...N} /><ellipse cx={212} cy={146} rx={12} ry={18} fill={sk} {...N} />
        <ellipse cx={150} cy={140} rx={62} ry={68} fill={sk} {...N} />
        {salam
          ? <path d="M90,122 Q92,86 150,82 Q208,86 210,122 Q192,96 150,96 Q108,96 90,122Z" fill={hair} {...N} />
          : <path d="M88,128 Q88,70 150,68 Q212,70 212,128 Q192,98 150,100 Q108,98 88,128Z" fill={hair} {...N} />}
        <Eye cx={122} r={er} blink={blink} lx={lx} ly={ly} /><Eye cx={178} r={er} blink={blink} lx={lx} ly={ly} />
        {baba && (<g fill="none" stroke="#111" strokeWidth={4} vectorEffect="non-scaling-stroke"><rect x={100} y={122} width={44} height={40} rx={14} /><rect x={156} y={122} width={44} height={40} rx={14} /><path d="M144,140 L156,140" /><path d="M100,136 L90,134 M200,136 L210,134" /></g>)}
        <path d="M104,112 L140,112" transform={`translate(0,${bdy}) rotate(${bl},122,112)`} {...N} strokeWidth={5} />
        <path d="M160,112 L196,112" transform={`translate(0,${bdy}) rotate(${br},178,112)`} {...N} strokeWidth={5} />
        {baba && <path d="M118,98 Q150,92 182,98 M126,90 Q150,85 174,90" fill="none" stroke="#9A6B3F" strokeWidth={2} opacity={0.6} />}
        <path d="M146,156 Q150,166 156,160" fill="none" {...N} strokeWidth={3} />
        {salam && <path d="M92,165 Q100,226 150,230 Q200,226 208,165 Q190,204 150,204 Q110,204 92,165Z" fill="#F2F2F2" {...N} />}
        <Mouth m={mouth} emo={emo} />
        {baba && <path d="M120,178 Q135,166 150,174 Q165,166 180,178 Q165,184 150,179 Q135,184 120,178Z" fill="#1B1B1B" {...N} strokeWidth={2} />}
        {(emo === 'happy' || emo === 'hopeful') && (<g opacity={0.5}><ellipse cx={100} cy={170} rx={13} ry={8} fill="#FF8FA3" /><ellipse cx={200} cy={170} rx={13} ry={8} fill="#FF8FA3" /></g>)}
        {p.tears && [122, 178].map((tx, i) => { const q = ((f * 2.4 + i * 22) % 60) / 60; return <ellipse key={tx} cx={tx} cy={162 + q * 44} rx={5} ry={8} fill="#5BC0F8" opacity={1 - q} />; })}
      </g>
    </g>
  );
};
