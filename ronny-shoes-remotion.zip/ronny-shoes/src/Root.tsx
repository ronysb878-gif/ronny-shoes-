import React from 'react';
import {Composition} from 'remotion';
import {Story} from './Video';
import {W, H, FPS, TOTAL} from './theme';

export const Root: React.FC = () => (
  <Composition id="Story" component={Story} durationInFrames={TOTAL} fps={FPS} width={W} height={H} />
);
