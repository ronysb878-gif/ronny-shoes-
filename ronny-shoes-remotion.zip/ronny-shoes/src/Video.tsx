import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile} from 'remotion';
import {SCENES, FPS, fontFamily} from './theme';
import {Overlays} from './UI';
import {S1} from './scenes/S1';
import {S2} from './scenes/S2';
import {S3} from './scenes/S3';
import {S4} from './scenes/S4';
import {S5} from './scenes/S5';
import {S6} from './scenes/S6';

const COMPS = [S1, S2, S3, S4, S5, S6];

export const Story: React.FC = () => (
  <AbsoluteFill style={{backgroundColor: '#161616', fontFamily}}>
    <Audio src={staticFile('voice.mp3')} />
    {SCENES.map((sc, i) => {
      const C = COMPS[i];
      const a = Math.round(sc.from * FPS), b = Math.round(sc.to * FPS);
      return (
        <Sequence key={sc.id} from={a} durationInFrames={b - a}>
          <C />
        </Sequence>
      );
    })}
    <Overlays />
  </AbsoluteFill>
);
