import React from 'react';
import {fontFamily, OUT} from './theme';

export const S = {stroke: OUT, strokeWidth: 4, strokeLinejoin: 'round', strokeLinecap: 'round'} as const;
export type Kind = 'old' | 'torn' | 'new' | 'sole' | 'fixed';
type G = {x?: number; y?: number; s?: number; rot?: number};
const T = (p: G) => `translate(${p.x ?? 0},${p.y ?? 0}) rotate(${p.rot ?? 0}) scale(${p.s ?? 1})`;
export const bn = (n: number) => String(n).replace(/\d/g, (d) => '০১২৩৪৫৬৭৮৯'[+d]);

/* ---------- জুতা (সাইড ভিউ, নিচের মাঝখান = origin, ডগা ডানদিকে) ---------- */
export const Shoe = ({kind, x = 0, y = 0, s = 1, flip = false, rot = 0}: {kind: Kind; flip?: boolean} & G) => {
  const col = kind === 'new' ? '#1C1C1C' : '#8B5A2B';
  const soleC = kind === 'new' ? '#3A3A3A' : kind === 'fixed' ? '#111' : '#4A2E14';
  const up = 'M-58,-6 L-58,-36 Q-57,-52 -40,-52 L-20,-52 Q-14,-30 6,-26 Q44,-24 58,-14 L58,-6 Z';
  const upT = 'M-58,-6 L-58,-36 Q-57,-52 -40,-52 L-20,-52 Q-14,-30 6,-26 L22,-25 L22,-6 Z';
  const laces = <path d="M-34,-48 L-24,-38 M-26,-50 L-16,-38 M-18,-42 L-8,-32" stroke={kind === 'new' ? '#bbb' : '#EEE'} strokeWidth={3} fill="none" />;
  return (
    <g transform={`translate(${x},${y}) rotate(${rot}) scale(${flip ? -s : s},${s})`}>
      {kind === 'torn' ? (
        <>
          <path d="M22,-25 L58,-14 L58,-6 L22,-6Z" fill="#F4F4F4" {...S} />
          <path d={upT} fill={col} {...S} />
          <g transform="rotate(-20,22,-8)"><path d="M22,-25 Q44,-24 58,-14 L58,-6 L22,-6Z" fill={col} {...S} /></g>
          {laces}
          <rect x={-60} y={-8} width={120} height={10} rx={4} fill={soleC} {...S} />
        </>
      ) : kind === 'sole' ? (
        <>
          <path d={up} fill={col} {...S} />
          {laces}
          <path d="M-58,-6 L58,-6 L58,16 Z" fill="#2b1a0c" />
          <path d="M-30,-6 L30,-6 L32,2 L-28,6Z" fill="#D8B98A" {...S} strokeWidth={2} />
          <g transform="rotate(10,-58,-4)"><rect x={-60} y={-6} width={120} height={10} rx={4} fill={soleC} {...S} /></g>
          <ellipse cx={22} cy={-4} rx={8} ry={26} fill="none" stroke="#E05555" strokeWidth={5} />
        </>
      ) : (
        <>
          <path d={up} fill={col} {...S} />
          {laces}
          <rect x={-60} y={-8} width={120} height={kind === 'fixed' ? 13 : 10} rx={4} fill={soleC} {...S} />
          {(kind === 'new' || kind === 'fixed') && <path d="M-44,-46 Q-34,-50 -24,-47" stroke="#fff" strokeWidth={4} fill="none" opacity={0.7} />}
        </>
      )}
    </g>
  );
};

/* ---------- ছোট প্রপস/আইকন (সবই origin-কেন্দ্রিক) ---------- */
export const Coin = ({x, y, s = 1}: G) => (
  <g transform={T({x, y, s})}>
    <circle r={26} fill="#F6C945" {...S} strokeWidth={3} />
    <circle r={18} fill="none" stroke="#C99A1A" strokeWidth={3} />
    <text y={10} textAnchor="middle" fontFamily={fontFamily} fontWeight={700} fontSize={26} fill="#8A6508">৳</text>
  </g>
);
export const Pot = ({x, y, s = 1, rot = 0, broke = 0}: G & {broke?: number}) => {
  if (broke <= 0)
    return (
      <g transform={T({x, y, s, rot})}>
        <ellipse rx={92} ry={76} fill="#C9683A" {...S} />
        <ellipse cy={-68} rx={40} ry={12} fill="#A9502C" {...S} />
        <rect x={-30} y={-74} width={60} height={9} rx={4} fill="#222" />
        <path d="M-60,-20 Q-50,-50 -20,-55" stroke="#E79A6B" strokeWidth={8} fill="none" strokeLinecap="round" />
      </g>
    );
  const pcs = [
    {d: [-140, -90], r: -70, p: 'M-80,-20 L-20,-60 L0,0 L-60,40Z'},
    {d: [130, -110], r: 80, p: 'M20,-60 L85,-10 L40,50 L0,0Z'},
    {d: [-30, 80], r: 30, p: 'M-60,40 L0,0 L40,50 L-10,70Z'},
    {d: [40, -150], r: 140, p: 'M-20,-60 L30,-65 L20,-40 L0,0Z'},
  ];
  return (
    <g transform={T({x, y, s})}>
      {pcs.map((c, i) => (
        <path key={i} d={c.p} fill="#C9683A" {...S} transform={`translate(${c.d[0] * broke},${c.d[1] * broke + 60 * broke * broke}) rotate(${c.r * broke})`} />
      ))}
    </g>
  );
};
export const Calendar = ({x, y, s = 1, pulse = 0}: G & {pulse?: number}) => {
  const days = ['র', 'সো', 'ম', 'বু', 'বৃ', 'শু', 'শ'];
  return (
    <g transform={T({x, y, s})}>
      <rect x={-190} y={-220} width={380} height={440} rx={30} fill="#fff" {...S} />
      <path d="M-190,-110 L-190,-190 Q-190,-220 -160,-220 L160,-220 Q190,-220 190,-190 L190,-110Z" fill="#E5484D" {...S} />
      <text y={-140} textAnchor="middle" fontFamily={fontFamily} fontWeight={700} fontSize={56} fill="#fff">পরের মাস</text>
      {[-110, 110].map((cx) => <rect key={cx} x={cx - 8} y={-244} width={16} height={46} rx={8} fill="#555" {...S} />)}
      {days.map((d, i) => <text key={d} x={-150 + i * 50} y={-72} textAnchor="middle" fontFamily={fontFamily} fontSize={26} fill="#888">{d}</text>)}
      {Array.from({length: 30}, (_, i) => {
        const c = (i + 3) % 7, r = Math.floor((i + 3) / 7), hi = i + 1 === 3, cx = -150 + c * 50, cy = -30 + r * 52;
        return (
          <g key={i}>
            {hi && <circle cx={cx} cy={cy - 10} r={27 + pulse * 5} fill="#FFD23F" {...S} stroke="#E5484D" />}
            <text x={cx} y={cy} textAnchor="middle" fontFamily={fontFamily} fontWeight={hi ? 700 : 500} fontSize={28} fill="#333">{bn(i + 1)}</text>
          </g>
        );
      })}
      <g transform="translate(0,275)">
        <rect x={-170} y={-40} width={340} height={80} rx={40} fill="#FFD23F" {...S} />
        <text y={14} textAnchor="middle" fontFamily={fontFamily} fontWeight={700} fontSize={44} fill="#222">প্রথম শুক্রবার</text>
      </g>
    </g>
  );
};
export const Rumal = ({x, y, s = 1, rot = 0}: G) => (
  <g transform={T({x, y, s, rot})}>
    <rect x={-60} y={-40} width={120} height={80} rx={16} fill="#4C78C8" {...S} />
    <path d="M-60,0H60M0,-40V40" stroke="#9DB8EA" strokeWidth={5} />
    <rect x={-30} y={-58} width={60} height={30} rx={6} fill="#7DBB6A" {...S} />
    <circle cy={-44} r={10} fill="#4C78C8" {...S} />
  </g>
);
export const Note = ({x, y, s = 1, rot = 0}: G) => (
  <g transform={T({x, y, s, rot})}>
    <rect x={-45} y={-24} width={90} height={48} rx={6} fill="#9BD18B" {...S} />
    <circle r={12} fill="#6FB35F" {...S} strokeWidth={3} />
  </g>
);
export const Paper = ({x, y, s = 1, rot = 0}: G) => (
  <g transform={T({x, y, s, rot})}>
    <rect x={-36} y={-26} width={72} height={52} rx={4} fill="#fff" {...S} />
    <path d="M0,-26V26M-36,0H36" stroke="#bbb" strokeWidth={3} />
  </g>
);
export const Newspaper = ({x, y, w = 240, h = 300, sy = 1}: {x: number; y: number; w?: number; h?: number; sy?: number}) => (
  <g transform={`translate(${x},${y}) scale(1,${sy})`}>
    <rect x={-w / 2} y={-h / 2} width={w} height={h} rx={6} fill="#EDE7D3" {...S} />
    <rect x={-w / 2 + 20} y={-h / 2 + 22} width={w - 40} height={34} fill="#555" />
    {[0, 1, 2, 3, 4, 5].map((i) => <path key={i} d={`M${-w / 2 + 20},${-h / 2 + 80 + i * 30}H${w / 2 - 20}`} stroke="#999" strokeWidth={5} />)}
  </g>
);
export const BusX = ({x, y, s = 1}: G) => (
  <g transform={T({x, y, s})}>
    <rect x={-100} y={-50} width={200} height={100} rx={22} fill="#F5C518" {...S} />
    {[-70, -20, 30].map((wx) => <rect key={wx} x={wx} y={-34} width={34} height={34} rx={6} fill="#CDEBFF" {...S} strokeWidth={3} />)}
    {[-60, 60].map((wx) => <circle key={wx} cx={wx} cy={52} r={20} fill="#333" {...S} />)}
    <path d="M-90,-80 L90,80 M90,-80 L-90,80" stroke="#E5484D" strokeWidth={22} strokeLinecap="round" />
  </g>
);
export const Office = ({x, y, s = 1}: G) => (
  <g transform={T({x, y, s})}>
    <rect x={-70} y={-110} width={140} height={220} rx={8} fill="#9FB4C7" {...S} />
    {[0, 1, 2, 3].map((r) => [0, 1].map((c) => <rect key={r + '-' + c} x={-46 + c * 52} y={-86 + r * 46} width={38} height={30} rx={4} fill="#EAF6FF" {...S} strokeWidth={3} />))}
    <rect x={-18} y={62} width={36} height={48} fill="#8B5A2B" {...S} />
  </g>
);
export const Heart = ({x, y, s = 1}: G) => (
  <g transform={T({x, y, s})}><path d="M0,34 C-70,-10 -44,-62 0,-28 C44,-62 70,-10 0,34Z" fill="#FF4D6D" {...S} /></g>
);
export const Exclaim = ({x, y, s = 1}: G) => (
  <g transform={T({x, y, s})}>
    <circle r={38} fill="#E5484D" {...S} />
    <text y={18} textAnchor="middle" fontFamily={fontFamily} fontWeight={700} fontSize={56} fill="#fff">!</text>
  </g>
);
export const Sparkle = ({x, y, s = 1, rot = 0}: G) => (
  <g transform={T({x, y, s, rot})}><path d="M0,-30 Q4,-4 30,0 Q4,4 0,30 Q-4,4 -30,0 Q-4,-4 0,-30Z" fill="#FFE066" {...S} strokeWidth={3} /></g>
);
export const Bat = ({x, y, s = 1, rot = 0}: G) => (
  <g transform={T({x, y, s, rot})}>
    <rect x={-18} y={-80} width={36} height={130} rx={14} fill="#E8C27A" {...S} />
    <rect x={-7} y={46} width={14} height={56} rx={6} fill="#7A4B21" {...S} />
  </g>
);
export const Tiffin = ({x, y, s = 1, rot = 0}: G) => (
  <g transform={T({x, y, s, rot})}>
    <path d="M-36,-52 Q0,-92 36,-52" fill="none" {...S} />
    <rect x={-56} y={-50} width={112} height={92} rx={16} fill="#C0C7D0" {...S} />
    <path d="M-56,-6H56" stroke="#222" strokeWidth={4} />
  </g>
);
export const Hammer = ({x, y, s = 1, rot = 0}: G) => (
  <g transform={T({x, y, s, rot})}>
    <rect x={-8} y={-10} width={16} height={90} rx={6} fill="#A86F3A" {...S} />
    <rect x={-34} y={-34} width={68} height={28} rx={6} fill="#777" {...S} />
  </g>
);
export const Thought = ({x, y, w = 380, h = 240, children}: {x: number; y: number; w?: number; h?: number; children?: React.ReactNode}) => (
  <g transform={`translate(${x},${y})`}>
    <circle cx={-w / 2 + 40} cy={h / 2 + 70} r={14} fill="#fff" {...S} />
    <circle cx={-w / 2 + 70} cy={h / 2 + 32} r={22} fill="#fff" {...S} />
    <ellipse rx={w / 2} ry={h / 2} fill="#fff" {...S} />
    {children}
  </g>
);

/* ---------- ব্যাকগ্রাউন্ড (সব ১০০% এজ-টু-এজ, ওভারস্ক্যানসহ) ---------- */
const Full = ({fill, y = -60, h = 2040}: {fill: string; y?: number; h?: number}) => <rect x={-60} y={y} width={1200} height={h} fill={fill} />;
const Grad = ({id, a, b}: {id: string; a: string; b: string}) => (
  <defs><linearGradient id={id} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor={a} /><stop offset="1" stopColor={b} /></linearGradient></defs>
);

export const BgSchool = () => (
  <g>
    <Grad id="gSchool" a="#8FD3F4" b="#E9F7FF" />
    <rect x={-60} y={-60} width={1200} height={1500} fill="url(#gSchool)" />
    <circle cx={900} cy={260} r={90} fill="#FFE066" />
    <ellipse cx={200} cy={300} rx={130} ry={44} fill="#fff" /><ellipse cx={300} cy={335} rx={100} ry={36} fill="#fff" />
    <rect x={110} y={640} width={860} height={740} fill="#F2D49B" {...S} />
    <path d="M80,640 L540,470 L1000,640Z" fill="#C8553D" {...S} />
    <path d="M540,470 V360" {...S} /><path d="M540,360 L640,390 L540,420Z" fill="#2F9E44" {...S} />
    {[720, 950].map((wy) => [0, 1, 2, 3].map((i) => <rect key={wy + '-' + i} x={190 + i * 190} y={wy} width={120} height={130} rx={8} fill="#BFE6FA" {...S} />))}
    <rect x={470} y={1120} width={140} height={260} fill="#8B5A2B" {...S} />
    <Full fill="#7BC96F" y={1380} h={700} />
    <rect x={-60} y={1450} width={1200} height={260} fill="#D9D2C5" />
    <rect x={30} y={1090} width={80} height={310} fill="#BDBDBD" {...S} /><rect x={970} y={1090} width={80} height={310} fill="#BDBDBD" {...S} />
  </g>
);
export const BgClass = () => (
  <g>
    <Full fill="#F6E7C8" h={1330} />
    <Full fill="#B98B5E" y={1250} h={800} />
    <rect x={130} y={230} width={820} height={380} rx={16} fill="#2F6B55" stroke="#8B5A2B" strokeWidth={14} />
    <path d="M200,320 H700 M200,400 H820 M200,480 H600" stroke="#EAF6EE" strokeWidth={8} strokeLinecap="round" opacity={0.85} />
    <rect x={380} y={700} width={320} height={260} rx={10} fill="#BFE6FA" {...S} /><path d="M540,700 V960 M380,830 H700" {...S} />
    <circle cx={910} cy={720} r={50} fill="#fff" {...S} /><path d="M910,720 V690 M910,720 L930,730" {...S} />
  </g>
);
// ডেস্কের সামনের প্যানেল (ক্যারেক্টারের পরে আঁকতে হয়, যাতে পা ঢাকা পড়ে)
export const ClassDesks = () => (
  <g>
    <rect x={320} y={1200} width={440} height={420} rx={14} fill="#B5733F" {...S} /><rect x={300} y={1180} width={480} height={34} rx={10} fill="#D79A62" {...S} />
    <rect x={-20} y={1290} width={330} height={400} rx={14} fill="#B5733F" {...S} /><rect x={-40} y={1272} width={370} height={30} rx={10} fill="#D79A62" {...S} />
    <rect x={770} y={1290} width={330} height={400} rx={14} fill="#B5733F" {...S} /><rect x={750} y={1272} width={370} height={30} rx={10} fill="#D79A62" {...S} />
  </g>
);
export const BgUnder = () => (
  <g>
    <Full fill="#C99A6B" />
    <rect x={-60} y={-60} width={1200} height={400} fill="#8A5A2B" {...S} />
    <rect x={230} y={330} width={50} height={1300} fill="#6E4520" {...S} /><rect x={810} y={330} width={50} height={1300} fill="#6E4520" {...S} />
    <rect x={-60} y={1210} width={1200} height={30} fill="#000" opacity={0.08} />
  </g>
);
export const BgNight = () => (
  <g>
    <Grad id="gNight" a="#22335E" b="#3A4C80" />
    <rect x={-60} y={-60} width={1200} height={1650} fill="url(#gNight)" />
    <rect x={660} y={240} width={300} height={400} rx={14} fill="#0F1B3D" stroke="#C69C6D" strokeWidth={12} /><path d="M810,240 V640 M660,440 H960" stroke="#C69C6D" strokeWidth={8} />
    <circle cx={880} cy={340} r={46} fill="#FFF3B0" /><circle cx={860} cy={330} r={40} fill="#0F1B3D" />
    {[[720, 300], [760, 540], [920, 520], [700, 450]].map(([sx, sy], i) => <circle key={i} cx={sx} cy={sy} r={4} fill="#fff" />)}
    <defs><radialGradient id="gLamp"><stop offset="0" stopColor="#FFD27A" stopOpacity={0.55} /><stop offset="1" stopColor="#FFD27A" stopOpacity={0} /></radialGradient></defs>
    <circle cx={150} cy={620} r={420} fill="url(#gLamp)" />
    <rect x={142} y={560} width={16} height={620} fill="#6B4A2B" {...S} /><path d="M80,620 L220,620 L190,520 L110,520Z" fill="#FFE3A3" {...S} />
    <Full fill="#4A3A2E" y={1560} h={500} />
    <rect x={30} y={940} width={1020} height={560} rx={60} fill="#8B4A3B" {...S} />
  </g>
);
export const SofaFront = () => (
  <g>
    <rect x={10} y={1270} width={1060} height={380} rx={50} fill="#A55A48" {...S} />
    <rect x={10} y={1250} width={1060} height={60} rx={30} fill="#BC6B57" {...S} />
  </g>
);
export const BgShop = () => (
  <g>
    <Full fill="#FFF1D6" h={1600} />
    <Full fill="#D9C3A0" y={1560} h={500} />
    {[430, 730, 1030].map((py, r) => (
      <g key={py}>
        <rect x={30} y={py} width={1020} height={24} rx={6} fill="#A86F3A" {...S} />
        {[0, 1, 2, 3, 4, 5, 6].map((i) => <Shoe key={i} kind={(i + r) % 2 ? 'new' : 'old'} x={110 + i * 142} y={py} s={0.58} />)}
      </g>
    ))}
    <rect x={620} y={1290} width={500} height={340} rx={10} fill="#B5733F" {...S} />
  </g>
);
export const ShopCounterTop = () => <rect x={600} y={1260} width={520} height={44} rx={10} fill="#D79A62" {...S} />;
export const BgStreet = ({shift = 0}: {shift?: number}) => (
  <g>
    <Grad id="gStreet" a="#FFD6A5" b="#FFF3D9" />
    <rect x={-60} y={-60} width={1200} height={1560} fill="url(#gStreet)" />
    {[[-20, 700, 260], [250, 560, 300], [560, 760, 240], [800, 620, 320]].map(([bx, by, bw], i) => (
      <g key={i}><rect x={bx} y={by} width={bw} height={1450 - by} fill={['#C9A27E', '#B88E6B', '#D6B48F', '#BF9672'][i]} {...S} />
        {[0, 1, 2].map((k) => <rect key={k} x={bx + 30 + (k % 2) * 110} y={by + 50 + Math.floor(k / 2) * 110} width={70} height={70} rx={6} fill="#FFF0C2" {...S} strokeWidth={3} />)}</g>
    ))}
    <Full fill="#7C838C" y={1450} h={600} />
    <rect x={-60} y={1450} width={1200} height={50} fill="#BDB6AA" />
    {Array.from({length: 8}, (_, i) => <rect key={i} x={((i * 220 - shift) % 1760) - 220} y={1790} width={120} height={14} rx={7} fill="#F5F5F5" />)}
    {[300, 640, 900].map((px, i) => <ellipse key={i} cx={px} cy={1640 + (i % 2) * 40} rx={90} ry={24} fill="#8CCBEF" {...S} strokeWidth={3} />)}
  </g>
);
export const BgHome = ({mode}: {mode: 'evening' | 'day' | 'morning'}) => {
  const wall = {evening: '#E6CFA9', day: '#EAD9BC', morning: '#FFF0CC'}[mode];
  const sky = {evening: '#F6A25B', day: '#BEE3F8', morning: '#FFE9A8'}[mode];
  return (
    <g>
      <Full fill={wall} h={1620} />
      <Full fill="#9C6B3F" y={1560} h={500} />
      <rect x={60} y={300} width={320} height={460} rx={12} fill={sky} stroke="#8B5A2B" strokeWidth={14} /><path d="M220,300 V760 M60,530 H380" stroke="#8B5A2B" strokeWidth={8} />
      {mode === 'morning' && <polygon points="60,300 380,300 760,1560 200,1560" fill="#fff" opacity={0.22} />}
      <rect x={680} y={380} width={320} height={1180} rx={10} fill="#8B5A2B" {...S} />
      <rect x={720} y={430} width={110} height={380} rx={8} fill="#A86F3A" {...S} strokeWidth={3} /><rect x={850} y={430} width={110} height={380} rx={8} fill="#A86F3A" {...S} strokeWidth={3} />
      <circle cx={960} cy={980} r={16} fill="#F6C945" {...S} />
      <rect x={640} y={1560} width={400} height={44} rx={8} fill="#B24B3A" {...S} />
      {mode === 'evening' && (<><defs><radialGradient id="gVig" cx="0.5" cy="0.5" r="0.75"><stop offset="0.5" stopColor="#3A2A1A" stopOpacity={0} /><stop offset="1" stopColor="#3A2A1A" stopOpacity={0.5} /></radialGradient></defs><rect x={-60} y={-60} width={1200} height={2040} fill="url(#gVig)" /></>)}
    </g>
  );
};
export const BgCobbler = () => (
  <g>
    <Full fill="#D4C3A3" h={1620} />
    {Array.from({length: 14}, (_, r) => Array.from({length: 6}, (_, c) => <rect key={r + '-' + c} x={-40 + c * 200 + (r % 2) * 100} y={r * 110} width={190} height={100} fill="#C9B38C" stroke="#B8A27A" strokeWidth={3} />))}
    <Full fill="#A8A39A" y={1560} h={500} />
    <path d="M-20,560 Q540,640 1100,560" stroke="#6B4A2B" strokeWidth={6} fill="none" />
    {[120, 300, 480, 660, 840, 1000].map((sx, i) => <g key={sx}><path d={`M${sx},${580 + Math.sin(sx / 300) * 8} V620`} stroke="#6B4A2B" strokeWidth={4} /><Shoe kind="old" x={sx} y={700} s={0.45} rot={90 * (i % 2 ? 1 : -1) * 0.05} /></g>)}
    <rect x={250} y={280} width={580} height={150} rx={18} fill="#2E4A62" {...S} />
    <text x={540} y={380} textAnchor="middle" fontFamily={fontFamily} fontWeight={700} fontSize={72} fill="#fff">জুতা মেরামত</text>
    <rect x={420} y={1500} width={170} height={70} rx={8} fill="#7A4B21" {...S} />
  </g>
);
export const BgClean = ({tint = '#FFF6E0'}: {tint?: string}) => (
  <g>
    <defs><radialGradient id="gClean" cx="0.5" cy="0.5" r="0.75"><stop offset="0.45" stopColor={tint} /><stop offset="1" stopColor="#E8D3A8" /></radialGradient></defs>
    <rect x={-60} y={-60} width={1200} height={2040} fill="url(#gClean)" />
  </g>
);
