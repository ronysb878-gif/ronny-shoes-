import React from 'react';
import {AbsoluteFill, Easing, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import {W, H, FPS, fontFamily, inR, pop} from './theme';
import {CAPS, BUBBLES, STAMPS, PILLS, Cap, Bub, Pill, Stamp} from './data';

// ফুল-স্ক্রিন সিন ক্যানভাস (১০০% এজ-টু-এজ); z/fx/fy = ক্যামেরা জুম, shake = স্ক্রিন শেক
export const Stage = ({children, z = 1, fx = 540, fy = 960, shake = 0}: {children: React.ReactNode; z?: number; fx?: number; fy?: number; shake?: number}) => {
  const f = useCurrentFrame();
  const op = interpolate(f, [0, 8], [0, 1], {extrapolateRight: 'clamp'});
  const sx = shake ? Math.sin(f * 2.7) * shake : 0, sy = shake ? Math.cos(f * 3.1) * shake : 0;
  return (
    <AbsoluteFill style={{opacity: op}}>
      <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{display: 'block'}}>
        <g transform={`translate(${sx},${sy}) translate(${fx},${fy}) scale(${z}) translate(${-fx},${-fy})`}>{children}</g>
      </svg>
    </AbsoluteFill>
  );
};

const BubbleView = ({b, t}: {b: Bub; t: number}) => {
  const p = pop(t, b.from, 0.35);
  const o = interpolate(t, [b.to - 0.15, b.to], [1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const tl = Math.min(Math.max(b.tx - b.x, 80), b.w - 80);
  return (
    <div style={{position: 'absolute', left: b.x, bottom: H - (b.y - 58), width: b.w, opacity: o, transform: `scale(${p})`, transformOrigin: `${tl}px calc(100% + 58px)`}}>
      <div style={{background: '#fff', border: '5px solid #222', borderRadius: 44, padding: '26px 34px', fontSize: 54, fontWeight: 700, lineHeight: 1.35, color: '#222', textAlign: 'center'}}>{b.text}</div>
      <svg width={80} height={64} viewBox="0 0 80 64" style={{position: 'absolute', left: tl - 40, top: '100%', marginTop: -6, overflow: 'visible'}}>
        <path d="M8,2 L40,58 L72,2" fill="#fff" stroke="#222" strokeWidth={5} strokeLinejoin="round" />
        <rect x={9} y={-6} width={62} height={9} fill="#fff" />
      </svg>
    </div>
  );
};
const PillView = ({p, t}: {p: Pill; t: number}) => {
  const k = pop(t, p.from, 0.35) * (t > p.to - 0.2 ? Math.max(0, (p.to - t) / 0.2) : 1);
  return (
    <div style={{position: 'absolute', left: p.x, top: p.y, transform: `translate(-50%,-50%) scale(${k})`, background: p.color, color: '#fff', border: '4px solid #222', borderRadius: 60, padding: '10px 38px', fontSize: 46, fontWeight: 700, whiteSpace: 'nowrap'}}>{p.text}</div>
  );
};
const StampView = ({s, t}: {s: Stamp; t: number}) => {
  const k = pop(t, s.from, 0.45);
  return (
    <div style={{position: 'absolute', left: s.x ?? 540, top: s.y ?? 520, transform: `translate(-50%,-50%) rotate(-6deg) scale(${k})`, border: `10px solid ${s.color ?? '#E5484D'}`, color: s.color ?? '#E5484D', background: 'rgba(255,255,255,.92)', borderRadius: 28, padding: '10px 44px', fontSize: 110, fontWeight: 700, whiteSpace: 'nowrap'}}>{s.text}</div>
  );
};
const CaptionView = ({c, t}: {c: Cap; t: number}) => {
  const p = interpolate(t, [c[0], c[0] + 0.25], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic)});
  const parts = c[2].split('*');
  return (
    <div style={{position: 'absolute', left: 0, right: 0, bottom: 170, display: 'flex', justifyContent: 'center', opacity: p, transform: `translateY(${(1 - p) * 30}px)`}}>
      <div style={{background: 'rgba(20,20,28,.78)', borderRadius: 36, padding: '16px 36px', fontSize: 44, fontWeight: 700, color: '#fff', textAlign: 'center', maxWidth: 980}}>
        {parts.map((s, i) => <span key={i} style={i % 2 ? {color: '#FFD23F'} : undefined}>{s}</span>)}
      </div>
    </div>
  );
};

// সব ওভারলে ফুল-স্ক্রিন দৃশ্যের ওপর ভাসমান। কলআউট/স্ট্যাম্প চলাকালীন নিচের ক্যাপশন লুকানো থাকে।
export const Overlays = () => {
  const t = useCurrentFrame() / FPS;
  useVideoConfig();
  const hide = BUBBLES.some((b) => inR(t, b.from, b.to)) || STAMPS.some((s) => inR(t, s.from, s.to));
  const cap = CAPS.find((c) => inR(t, c[0], c[1]));
  return (
    <AbsoluteFill style={{fontFamily}}>
      {PILLS.filter((p) => inR(t, p.from, p.to)).map((p, i) => <PillView key={'p' + i} p={p} t={t} />)}
      {BUBBLES.filter((b) => inR(t, b.from, b.to + 0.15)).map((b, i) => <BubbleView key={'b' + i} b={b} t={t} />)}
      {STAMPS.filter((s) => s.text && inR(t, s.from, s.to)).map((s, i) => <StampView key={'s' + i} s={s} t={t} />)}
      {cap && !hide && <CaptionView key={cap[0]} c={cap} t={t} />}
    </AbsoluteFill>
  );
};
