import {interpolate, Easing, useCurrentFrame} from 'remotion';
import {loadFont} from '@remotion/google-fonts/HindSiliguri';

export const {fontFamily} = loadFont('normal', {weights: ['500', '700'], subsets: ['bengali', 'latin']});
export const W = 1080, H = 1920, FPS = 30, TOTAL = 3892; // 129.72s audio
export const OUT = '#222222';

// সিনের শুরু/শেষ (সেকেন্ড, অডিও/SRT অনুযায়ী)
export const SCENES = [
  {id: 1, from: 0, to: 20.12},
  {id: 2, from: 20.12, to: 39.9},
  {id: 3, from: 39.9, to: 53.52},
  {id: 4, from: 53.52, to: 85.16},
  {id: 5, from: 85.16, to: 106.74},
  {id: 6, from: 106.74, to: TOTAL / FPS},
];

const C = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
export const lerp = (t: number, a: number, b: number, v0: number, v1: number) =>
  interpolate(t, [a, b], [v0, v1], {...C, easing: Easing.inOut(Easing.quad)});
export const pop = (t: number, s: number, d = 0.4) =>
  interpolate(t, [s, s + d], [0, 1], {...C, easing: Easing.out(Easing.back(1.8))});
export const fade = (t: number, a: number, b: number, e = 0.25) => {
  const k = Math.min(e, (b - a) / 2.01);
  return interpolate(t, [a, a + k, b - k, b], [0, 1, 1, 0], C);
};
export const inR = (t: number, a: number, b: number) => t >= a && t < b;
// সিনের ভেতরে: f = লোকাল ফ্রেম, t = পুরো ভিডিওর অ্যাবসোলিউট সেকেন্ড
export const useScene = (i: number) => {
  const f = useCurrentFrame();
  return {f, t: SCENES[i].from + f / FPS};
};
