import React from 'react';
import {Character} from '../Character';
import {BgNight, SofaFront, BgHome, Newspaper, Shoe, Paper, S} from '../Art';
import {Stage} from '../UI';
import {useScene, lerp, inR} from '../theme';

// দৃশ্য ২ (০:২০–০:৪০): রাতে বাবা-ছেলে, তারপর ছেঁড়া জুতায় কাগজ গোঁজা
export const S2 = () => {
  const {t} = useScene(1);
  const FE = 1500;

  if (t < 35.34) {
    const fold = lerp(t, 24.6, 25.4, 0, 1);
    const babaTalk = inR(t, 27.5, 31.7);
    return (
      <Stage z={lerp(t, 20.12, 35.34, 1, 1.06)} fx={540} fy={1000}>
        <BgNight />
        <Character who="ronny" x={330} y={FE} hideLegs emo={t < 31.7 ? 'hopeful' : 'sad'} talk={inR(t, 20.12, 24.4)} lookX={0.6} lookY={t > 31.7 ? 1 : 0} armL={6} armR={6} seed={1} />
        <Character who="baba" x={730} y={FE} hideLegs noArms={t < 24.6} emo={babaTalk ? 'happy' : 'normal'} talk={babaTalk} lookX={-1} armL={-35} armR={-35} seed={3} />
        {/* খবরের কাগজ: প্রথমে মুখের সামনে, তারপর ভাঁজ হয়ে হাঁটুতে */}
        <Newspaper x={730} y={1119 + fold * 190} w={240} h={300} sy={1 - fold * 0.72} />
        {fold < 0.5 && <g><circle cx={612} cy={1119} r={22} fill="#D9A06F" {...S} /><circle cx={848} cy={1119} r={22} fill="#D9A06F" {...S} /></g>}
        <SofaFront />
      </Stage>
    );
  }

  // পরদিন সকাল: ছেঁড়া জুতার ফাঁকে ভাঁজ করা কাগজ গোঁজা
  const q = lerp(t, 36.4, 37.6, 0, 1);
  return (
    <Stage z={lerp(t, 35.34, 39.9, 1, 1.08)} fx={540} fy={1250}>
      <BgHome mode="morning" />
      <Shoe kind="torn" x={500} y={1380} s={3.4} />
      <g transform={`translate(${540 + q * 140},${520 + q * 740}) rotate(${-25 + q * 25}) scale(${1.6 - q * 0.35})`} opacity={t < 38.0 ? 1 : 0.0}>
        <Paper />
      </g>
      {t >= 38.0 && <g transform="translate(680,1262) scale(1.25)"><Paper rot={0} /></g>}
    </Stage>
  );
};
