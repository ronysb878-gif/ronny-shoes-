import React from 'react';
import {Character} from '../Character';
import {BgHome, Shoe, Exclaim, Sparkle, Heart} from '../Art';
import {Stage} from '../UI';
import {useScene, lerp, pop, inR} from '../theme';

// দৃশ্য ৬ (১:৪৭–২:০৯): সকালে নতুন তলার জুতা দেখে বাবা, রনির মাথায় হাত, ফিতা বাঁধা, নীরব ভালোবাসা
export const S6 = () => {
  const {t} = useScene(5);
  const FE = 1540;
  const fadeOut = lerp(t, 129.1, 129.72, 0, 1);
  const out = <rect x={-60} y={-60} width={1200} height={2040} fill="#000" opacity={fadeOut} />;

  // ফিতা বাঁধার ক্লোজ-আপ
  if (inR(t, 120.6, 124.5)) {
    const w = Math.sin(t * 5);
    return (
      <Stage z={lerp(t, 120.6, 124.5, 1, 1.1)} fx={540} fy={1250}>
        <BgHome mode="morning" />
        <Shoe kind="fixed" x={540} y={1400} s={3.6} />
        <ellipse cx={500 - w * 6} cy={1180} rx={46} ry={22} fill="none" stroke="#fff" strokeWidth={8} transform="rotate(-20,500,1180)" />
        <ellipse cx={590 + w * 6} cy={1180} rx={46} ry={22} fill="none" stroke="#fff" strokeWidth={8} transform="rotate(20,590,1180)" />
        <circle cx={420 + w * 40} cy={1060 + Math.abs(w) * 30} r={42} fill="#D9A06F" stroke="#222" strokeWidth={4} />
        <circle cx={660 - w * 40} cy={1060 + Math.abs(w) * 30} r={42} fill="#D9A06F" stroke="#222" strokeWidth={4} />
        {[0, 1].map((i) => { const q = ((t * 0.9 + i * 0.5) % 1); return <ellipse key={i} cx={640} cy={300 + q * 760} rx={9} ry={14} fill="#5BC0F8" opacity={1 - q * 0.6} />; })}
        {out}
      </Stage>
    );
  }

  const z = inR(t, 110.0, 113.6) ? (t < 111 ? lerp(t, 110.0, 110.9, 1, 1.9) : lerp(t, 112.8, 113.6, 1.9, 1)) : t >= 124.5 ? lerp(t, 124.5, 129.72, 1.25, 1.0) : 1;
  const fz = inR(t, 110.0, 113.6);
  const bx = t < 108.2 ? lerp(t, 106.74, 108.2, 1250, 870) : t < 114.0 ? 870 : t < 115.4 ? lerp(t, 114.0, 115.4, 870, 760) : t < 124.5 ? 760 : 640;
  const rxn = t < 114.4 ? -200 : t < 115.4 ? lerp(t, 114.4, 115.4, -200, 440) : t < 124.5 ? 440 : 440;
  const hand = lerp(t, 115.66, 116.4, 4, 130);
  const end = t >= 124.5;
  const shoesVisible = t < 120.6 || false;
  return (
    <Stage z={z} fx={fz ? 590 : 540} fy={fz ? 1520 : 1000} shake={inR(t, 108.2, 109) ? 3 : 0}>
      <BgHome mode="morning" />
      {shoesVisible && (<><Shoe kind="fixed" x={520} y={1545} s={0.95} /><Shoe kind="fixed" x={630} y={1545} s={0.95} /></>)}
      {inR(t, 110.9, 113.2) && [[470, 1460], [690, 1470], [580, 1420]].map(([sx, sy], i) => <Sparkle key={i} x={sx} y={sy} s={pop(t, 110.9 + i * 0.2) * (0.8 + Math.sin(t * 8 + i) * 0.2)} rot={t * 40} />)}
      {t >= 114.4 && <Character who="ronny" x={rxn} y={FE} walk={t < 115.4} emo={t < 115.66 ? 'worried' : 'happy'} tears={t >= 115.66} tilt={t >= 115.66 ? 6 : 0} lookX={t < 115.4 ? 1 : 0.5} shoeL="new" shoeR="new" seed={2} />}
      <Character who="baba" x={bx} y={FE} s={1.45} walk={inR(t, 106.74, 108.2) || inR(t, 114.0, 115.4)} socks={t < 124.5} shoeL="fixed" shoeR="fixed"
        emo={t < 108.2 ? 'normal' : t < 110.0 ? 'surprised' : 'happy'} tears={t >= 113.2} tremble={inR(t, 108.2, 110) ? 1.5 : 0}
        lookX={t >= 115.4 && t < 124.5 ? -1 : 0} lookY={inR(t, 110, 115.4) ? 1 : 0} talk={inR(t, 118.36, 120.6)} armL={t >= 115.66 && t < 124.5 ? hand : 4} seed={3} />
      <g transform={`translate(870,720) scale(${pop(t, 108.4) * (t < 110.0 ? 1 : 0)})`}><Exclaim /></g>
      {end && t >= 127.3 && <g transform={`translate(540,640) scale(${pop(t, 127.3) * (1 + Math.sin(t * 6) * 0.08)})`}><Heart s={1.8} /></g>}
      {out}
    </Stage>
  );
};
