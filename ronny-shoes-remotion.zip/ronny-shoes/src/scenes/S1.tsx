import React from 'react';
import {Character} from '../Character';
import {BgSchool, BgClass, ClassDesks, BgUnder, Shoe, Exclaim, Sparkle, S} from '../Art';
import {Stage} from '../UI';
import {useScene, lerp, pop, inR} from '../theme';

// দৃশ্য ১ (০:০০–০:২০): স্কুল গেট → ক্লাসরুম → বেঞ্চের নিচে পায়ের ক্লোজ-আপ
export const S1 = () => {
  const {t} = useScene(0);

  if (t < 12.36) {
    const x = t < 1.8 ? lerp(t, 0, 1.8, -160, 540) : t < 8 ? 540 : lerp(t, 8, 12.3, 540, 800);
    const walk = t < 1.8 || t > 8;
    const z = t < 6.6 ? lerp(t, 4.2, 5.0, 1, 2.1) : lerp(t, 6.6, 7.6, 2.1, 1);
    const ex = pop(t, 5.4) * (t < 7.4 ? 1 : 0);
    return (
      <Stage z={z} fx={560} fy={1450}>
        <BgSchool />
        <Character who="extra" x={lerp(t, 0, 12.36, 1250, -200)} y={1470} s={1.0} flip walk shirt="#6FA8DC" shoeL="new" shoeR="new" seed={5} />
        <Character who="extra" x={lerp(t, 0, 12.36, -300, 950)} y={1470} s={0.95} walk shirt="#E57373" hair="#3A2A1A" shoeL="new" shoeR="new" seed={8} />
        <Character who="ronny" x={x} y={1540} walk={walk} emo={t < 2.2 ? 'normal' : 'worried'} lookY={t > 4.4 ? 1 : 0} lookX={t > 8 ? 1 : 0} shoeL="torn" shoeR="old" seed={2} />
        <g transform={`translate(660,1330) scale(${ex})`}><Exclaim /></g>
      </Stage>
    );
  }

  if (t < 14.8) {
    return (
      <Stage fx={540} fy={1200} z={lerp(t, 12.36, 14.8, 1, 1.12)}>
        <BgClass />
        <Character who="extra" x={160} y={1500} s={1.1} hideLegs shirt="#6FA8DC" emo="happy" seed={7} />
        <Character who="extra" x={920} y={1500} s={1.1} hideLegs flip shirt="#E57373" emo="happy" seed={9} />
        <Character who="ronny" x={540} y={1500} s={1.4} hideLegs emo="sad" lookY={1} seed={2} />
        <ClassDesks />
      </Stage>
    );
  }

  // বেঞ্চের নিচে: রনির ছেঁড়া জুতা পেছনে গুটিয়ে যায়, বাকিদের চকচকে নতুন জুতা
  const p = lerp(t, 15.0, 15.8, 0, 1);
  const sp = pop(t, 16.2, 0.5);
  const pulse = 1 + Math.sin(t * 6) * 0.15;
  return (
    <Stage fx={540} fy={1100} z={lerp(t, 14.8, 20.12, 1, 1.18)}>
      <BgUnder />
      <rect x={360} y={-40} width={110} height={1180} rx={40} fill="#1F3A6B" {...S} />
      <rect x={520} y={-40} width={110} height={1180} rx={40} fill="#1F3A6B" {...S} />
      <Shoe kind="torn" x={415 + 130 * p} y={1200} s={1.9} rot={p * 6} />
      <Shoe kind="old" x={575} y={1200} s={1.9} />
      <rect x={60} y={-40} width={90} height={1180} rx={34} fill="#556B2F" {...S} /><rect x={170} y={-40} width={90} height={1180} rx={34} fill="#556B2F" {...S} />
      <Shoe kind="new" x={105} y={1200} s={1.5} /><Shoe kind="new" x={215} y={1200} s={1.5} />
      <rect x={820} y={-40} width={90} height={1180} rx={34} fill="#6A4C93" {...S} /><rect x={930} y={-40} width={90} height={1180} rx={34} fill="#6A4C93" {...S} />
      <Shoe kind="new" x={865} y={1200} s={1.5} flip /><Shoe kind="new" x={975} y={1200} s={1.5} flip />
      {[[130, 1110], [240, 1130], [850, 1110], [960, 1130]].map(([sx, sy], i) => (
        <Sparkle key={i} x={sx} y={sy} s={sp * pulse * (0.8 + (i % 2) * 0.3)} rot={t * 40 * (i % 2 ? 1 : -1)} />
      ))}
    </Stage>
  );
};
