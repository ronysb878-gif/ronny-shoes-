import React from 'react';
import {Character} from '../Character';
import {BgHome, BgStreet, Shoe, Exclaim, BusX, Office, Thought} from '../Art';
import {Stage} from '../UI';
import {useScene, lerp, pop, inR} from '../theme';

// দৃশ্য ৪ (০:৫৩–১:২৫): বাবার ছেঁড়া জুতা আবিষ্কার → ফ্ল্যাশব্যাক (হেঁটে অফিস) → বাবার সংলাপ → রনির চেপে রাখা কথা
export const S4 = () => {
  const {t} = useScene(3);
  const FE = 1540;

  // ফ্ল্যাশব্যাক: বাবা বাসে না উঠে হেঁটে অফিসে যাচ্ছেন
  if (inR(t, 70.2, 77.34)) {
    const bus = lerp(t, 70.8, 73.0, -250, 1350);
    return (
      <Stage>
        <BgStreet shift={t * 200} />
        <rect x={-60} y={-60} width={1200} height={2040} fill="#D9B98A" opacity={0.28} />
        <g transform={`translate(${bus},1330)`}><rect x={-100} y={-50} width={200} height={100} rx={22} fill="#F5C518" stroke="#222" strokeWidth={4} /></g>
        <Character who="baba" x={540} y={1700} s={1.4} walk emo="normal" lookX={1} shoeL="old" shoeR="sole" seed={3} />
        <g transform={`translate(540,520) scale(${pop(t, 71.4) * (t < 73.6 ? 1 : 0)})`}><BusX s={1.5} /></g>
        <g transform={`translate(540,520) scale(${pop(t, 73.8) * (t < 75.5 ? 1 : 0)})`}><Office s={1.6} /></g>
      </Stage>
    );
  }

  // সন্ধ্যার ঘর
  const rx = t < 55.5 ? lerp(t, 53.52, 55.5, -120, 320) : 320 - lerp(t, 80.5, 85.0, 0, 70);
  const walk = t < 55.5;
  const z = t < 67.6 ? lerp(t, 59.8, 60.8, 1, 2.0) : lerp(t, 67.6, 68.4, 2.0, 1);
  const z2 = t > 82.1 ? lerp(t, 82.1, 85.16, 1, 1.3) : 1;
  const zoom = t < 69 ? z : z2;
  const emo = t < 57.18 ? 'normal' : t < 60.24 ? 'surprised' : 'sad';
  const babaIn = t >= 77.0;
  const bx = lerp(t, 77.0, 77.5, 1300, 880);
  const talk = inR(t, 77.34, 79.9);
  const nod = inR(t, 79.9, 81.2) ? Math.sin((t - 79.9) * 10) * 8 : 0;
  return (
    <Stage z={zoom} fx={t > 82 ? 300 : 790} fy={t > 82 ? 900 : 1500} shake={t > 83.6 ? 1.2 : 0}>
      <BgHome mode="evening" />
      {/* বাবার জুতাজোড়া মেঝেতে */}
      <Shoe kind="old" x={650} y={1545} s={1.1} />
      <Shoe kind="sole" x={820} y={1545} s={1.1} />
      {inR(t, 63.2, 64.6) && <circle cx={842} cy={1522} r={48 + Math.sin(t * 14) * 5} fill="none" stroke="#FF4D4D" strokeWidth={6} />}
      {inR(t, 66.3, 67.8) && <circle cx={812} cy={1527} r={52 + Math.sin(t * 14) * 5} fill="none" stroke="#FF4D4D" strokeWidth={6} />}
      <Character who="ronny" x={rx} y={FE} walk={walk} emo={emo} lookX={t > 57.18 && t < 80 ? 1 : 0} lookY={t > 80 ? 1 : 0} tilt={nod} tremble={t > 83.6 ? 1.2 : 0}
        tears={t > 83.6} armR={-25} holdR={t < 80 ? <Shoe kind="torn" s={0.5} rot={-20} /> : undefined} shoeL="torn" shoeR="old" seed={2} />
      <g transform={`translate(330,760) scale(${pop(t, 57.3) * (t < 59.8 ? 1 : 0)})`}><Exclaim /></g>
      {babaIn && <Character who="baba" x={bx} y={FE} s={1.35} flip emo="happy" talk={talk} lookX={-1} socks seed={3} />}
      {inR(t, 82.1, 85.16) && (
        <g transform={`scale(${pop(t, 82.1)})`} style={{transformOrigin: '420px 600px'}}>
          <Thought x={430} y={600} w={300} h={180}>
            {[-70, 0, 70].map((dx, i) => <circle key={i} cx={dx} cy={Math.sin(t * 6 + i) * 8} r={13} fill="#555" />)}
          </Thought>
        </g>
      )}
    </Stage>
  );
};
