import React from 'react';
import {Character} from '../Character';
import {BgHome, BgCobbler, Pot, Coin, Thought, Bat, Tiffin, Shoe, Hammer} from '../Art';
import {Stage} from '../UI';
import {useScene, lerp, pop, inR} from '../theme';

// দৃশ্য ৫ (১:২৫–১:৪৭): মাটির ব্যাংক ভাঙা → মুচি কাকার দোকান → মুদ্রা ঢেলে দেওয়া
export const S5 = () => {
  const {t} = useScene(4);

  if (t < 93.96) {
    const broke = lerp(t, 87.9, 88.6, 0, 1);
    const hit = t < 86.9 ? 0 : t < 87.8 ? lerp(t, 86.9, 87.7, 0, 1) : lerp(t, 87.8, 88.1, 1, 0);
    const armR = 4 + hit * 126 - (t > 87.7 ? 0 : 0);
    const N = 14;
    const pulse = inR(t, 92.28, 93.96) ? 1 + Math.sin(t * 12) * 0.12 : 1;
    return (
      <Stage z={lerp(t, 85.16, 93.96, 1, 1.1)} fx={540} fy={1100}>
        <BgHome mode="day" />
        <Character who="ronny" x={380} y={1560} hideLegs emo={t < 86.86 ? 'sad' : 'determined'} lookX={1} lookY={0.4} armR={t < 86.9 ? 4 : t < 87.8 ? 4 + hit * 126 : 75 - lerp(t, 87.8, 88.4, 0, 70)} seed={2} />
        <rect x={-60} y={1262} width={1200} height={400} fill="#B5733F" stroke="#222" strokeWidth={4} />
        <rect x={-60} y={1240} width={1200} height={36} fill="#D79A62" stroke="#222" strokeWidth={4} />
        {t < 87.9 ? <Pot x={720} y={1170} rot={t > 86.9 ? Math.sin(t * 45) * 5 : 0} /> : <Pot x={720} y={1170} broke={Math.max(broke, 0.001)} />}
        {t >= 87.9 && Array.from({length: N}, (_, i) => {
          const q = Math.min(1, (t - 87.9) / 0.6), fx = 600 + (i % 7) * 50, fy = 1232 - Math.floor(i / 7) * 26;
          return <g key={i} transform={`translate(${720 + (fx - 720) * q},${1170 + (fy - 1170) * q - Math.sin(q * Math.PI) * 180}) scale(${0.55 * pulse})`}><Coin /></g>;
        })}
        {inR(t, 88.6, 92.4) && (
          <g transform={`scale(${pop(t, 88.6)})`} style={{transformOrigin: '400px 755px'}}>
            <Thought x={560} y={560} w={400} h={250}>
              <Bat x={-70} y={0} s={0.9} rot={30} /><Tiffin x={90} y={10} s={0.9} />
            </Thought>
          </g>
        )}
      </Stage>
    );
  }

  // মুচি কাকা সালামের দোকান
  const rx = t < 95.9 ? lerp(t, 93.96, 95.9, -120, 250) : 250;
  const walk = t < 95.9;
  const pour = t >= 103.56;
  const look = lerp(t, 98, 98.8, 0, 1);
  const sArmR = t < 98 ? 10 : -40 * look;
  const coins = Array.from({length: 12}, (_, i) => (t - 103.8 - i * 0.14) / 0.7);
  return (
    <Stage z={lerp(t, 93.96, 106.74, 1, 1.06)} fx={540} fy={1100}>
      <BgCobbler />
      <Character who="salam" x={800} y={1560} emo="normal" talk={inR(t, 98, 103.5)} lookX={-1} armR={sArmR} armL={pour ? 70 : 4}
        holdR={t < 98 ? <Hammer s={0.7} rot={20} /> : <Shoe kind="sole" s={0.5} rot={t > 98.8 ? Math.sin(t * 3) * 25 : 0} />} seed={5} />
      <Character who="ronny" x={rx} y={1560} walk={walk} emo={pour ? 'sad' : 'hopeful'} lookX={1} armR={pour ? 75 : 4} shoeL="torn" shoeR="old" seed={2} />
      {coins.map((q, i) => q >= 0 && q <= 1 && (
        <g key={i} transform={`translate(${515 + q * 38},${1130 - Math.sin(q * Math.PI) * 40 + q * 36}) scale(0.5)`}><Coin /></g>
      ))}
    </Stage>
  );
};
