import React from 'react';
import {Character} from '../Character';
import {BgClean, BgShop, ShopCounterTop, BgStreet, Calendar, Rumal, Note, Shoe, Coin, Sparkle} from '../Art';
import {Stage} from '../UI';
import {useScene, lerp, pop, inR} from '../theme';

// দৃশ্য ৩ (০:৪০–০:৫৩): ক্যালেন্ডার (ক্লিন মোশন গ্রাফিক্স) → জুতার দোকান → রাস্তায় নতুন জুতা
export const S3 = () => {
  const {t} = useScene(2);

  if (t < 42.3) {
    const k = pop(t, 40.0, 0.5) * (t > 41.9 ? Math.max(0, (42.3 - t) / 0.4) : 1);
    return (
      <Stage>
        <BgClean />
        <g transform={`translate(540,900) scale(${1.9 * k})`}><Calendar pulse={Math.sin(t * 8) * 0.5 + 0.5} /></g>
      </Stage>
    );
  }

  if (t < 48.9) {
    const count = inR(t, 44.46, 47.04);
    const give = lerp(t, 47.04, 47.9, 0, 1);
    const armR = t < 44.46 ? 4 : t < 47.04 ? -50 + Math.sin(t * 9) * 8 : -50 + give * 130;
    return (
      <Stage z={lerp(t, 42.3, 48.9, 1, 1.08)} fx={540} fy={1000}>
        <BgShop />
        <Character who="extra" x={860} y={1560} s={1.25} hideLegs flip emo="happy" shirt="#6C8E6B" hair="#8A8A8A" seed={4} />
        <ShopCounterTop />
        <Character who="baba" x={240} y={1540} s={1.3} lookX={1} emo="happy" armR={armR} holdR={t < 47.04 ? <Rumal s={0.45} /> : <Note s={0.5} />} seed={6} />
        <Character who="ronny" x={500} y={1540} s={1.3} emo="hopeful" lookX={0} lookY={-0.5} shoeL="torn" shoeR="old" seed={2} />
        {count && [0, 1, 2].map((i) => (
          <g key={i} transform={`translate(${300 + i * 50},${950 - ((t * 60 + i * 40) % 120)})`} opacity={1 - ((t * 60 + i * 40) % 120) / 120}><Note s={0.45} /></g>
        ))}
        {t > 47.6 && <g transform={`translate(740,1240) scale(${pop(t, 47.6)})`}><Shoe kind="new" s={1.0} /></g>}
      </Stage>
    );
  }

  // রাস্তা: নতুন জুতা পরে পানির ছিটা বাঁচিয়ে লাফিয়ে লাফিয়ে বাড়ি ফেরা
  const x = lerp(t, 48.9, 53.3, -120, 1200);
  const P = [300, 640, 900];
  let hop = 0;
  P.forEach((px) => { const d = Math.abs(x - px); if (d < 130) hop = Math.max(hop, 120 * Math.cos((d / 130) * Math.PI / 2)); });
  return (
    <Stage>
      <BgStreet shift={t * 160} />
      {P.map((px, i) => Math.abs(x - px) < 90 && (
        <g key={i}>{[-40, 0, 40].map((dx, k) => <circle key={k} cx={px + dx} cy={1590 - Math.abs(Math.sin(t * 14 + k)) * 40} r={9} fill="#8CCBEF" />)}</g>
      ))}
      <Character who="ronny" x={x} y={1700 - hop} s={1.4} walk emo="happy" lookX={1} shoeL="new" shoeR="new" seed={2} />
      <Sparkle x={x - 30} y={1690 - hop} s={0.6 + Math.sin(t * 9) * 0.2} rot={t * 50} />
      <Sparkle x={x + 60} y={1700 - hop} s={0.5 + Math.cos(t * 9) * 0.2} rot={-t * 50} />
    </Stage>
  );
};
