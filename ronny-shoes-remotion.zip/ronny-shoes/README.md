# রনির জুতা – Remotion প্রজেক্ট (1080x1920, 30fps, ৩৮৯২ ফ্রেম)
npm install
npx remotion studio
npx remotion render Story out/story.mp4
